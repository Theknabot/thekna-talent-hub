import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import multer from 'multer';
import dotenv from 'dotenv';
import nodemailer from 'nodemailer';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

import Job from './models/Job.js';
import Applicant from './models/Applicant.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const uploadPath = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadPath)) fs.mkdirSync(uploadPath);

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, 'uploads/'),
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

app.get('/api/jobs', async (req, res) => {
  const jobs = await Job.find();
  res.json(jobs);
});

app.post('/api/jobs', async (req, res) => {
  const job = await Job.create(req.body);
  res.json(job);
  // notificar (en producción se usaría Mailchimp o lista de correos)
});

app.post('/api/applicants', upload.single('cv'), async (req, res) => {
  const applicant = await Applicant.create({
    ...req.body,
    cv: req.file.filename
  });

  await transporter.sendMail({
    from: 'TechJobsNow <noreply@techjobsnow.com>',
    to: applicant.email,
    subject: 'Postulación recibida',
    text: `Hola ${applicant.name}, hemos recibido tu postulación para el área de ${applicant.area}. ¡Gracias por aplicar!`
  });

  res.json({ success: true });
});

app.listen(5000, () => {
  console.log('Backend corriendo en http://localhost:5000');
});