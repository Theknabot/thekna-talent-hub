import mongoose from 'mongoose';

const ApplicantSchema = new mongoose.Schema({
  name: String,
  email: String,
  phone: String,
  area: String,
  cv: String
});

export default mongoose.model('Applicant', ApplicantSchema);